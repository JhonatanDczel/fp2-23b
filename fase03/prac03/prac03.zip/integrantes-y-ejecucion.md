# Comparacion de rendimientos en RAM

## Integrantes:
+ Jhonatan David Arias Quispe
+ Jhossep Fabritzio Velarde Saldaña

## Para ejecutar el proyecto:
Para compilar los archivos:
```bash
javac *.java
```

- Medicion del rendimiento sin agregar un patron de diseño:
```bash
java TableroGUI.java
```

- Medicion del rendimiento con un patron de diseño (Singleton):
```bash
java TableroSingleton.java 
```
